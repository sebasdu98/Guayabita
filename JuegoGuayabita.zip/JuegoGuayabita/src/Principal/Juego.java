
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

/**
 *
 * @author Estudiantes
 */
public class Juego {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Apuesta(DineroJ1(500),DineroJ2(500),1,0);
        //Jugar(lanzar(),0);
    }

    public static int lanzar(){
       return (int) ((Math.random()*6)+1);
    }
    public static int Jugar(int a,int b){
        System.out.println("Saco:"+a);
        if(a==1 || a==6){
            System.out.println("Perdiste");
            return 0;
        }else{
            System.out.println("Apuestas, vuelves a tirar el dado");
            return Aux(lanzar(),a);
        } 
    }
    public static int Aux(int a,int b){
        System.out.println("Saco:"+a);
        if(a!=1 && a!=6){
            if(a>b){
                System.out.println("Ganaste");
                return 1;
            }else{
                System.out.println("Perdiste");
                return 0;
            }
        }else{
            System.out.println("Perdiste");
            return 0;
        }
    }
    public static void Apuesta(int a,int b,int c,int d){
        
        System.out.println("Plata de J1 "+a+"----"+"Plata de J2 "+b);
        if(a>0 && b>0){
            System.out.println("Turno "+c+++"    Total en mesa:"+d);
            if(c%2==0){
                System.out.println("Jugador J1 Lanzara");
            }else{
                System.out.println("Jugador J2 Lanzara");
            }
            if(Jugar(lanzar(),0)==0){
                if(c%2==0){
                    Apuesta(DineroJ1(DineroJ1(a-Minima(100))),DineroJ2(b),c,d+Minima(100));
                }else{
                    Apuesta(DineroJ1(a),DineroJ2(b-Minima(100)),c,d+Minima(100));
                }
            }else{
                if(c%2==0){
                    Apuesta(DineroJ1(a+d),DineroJ2(b),c,0);
                }else{
                    Apuesta(DineroJ1(a),DineroJ2(b+d),c,0);
                }
            }
            
        }else{
            if(a==0){
                 System.out.println("Perdio J1");
            }else{
                 System.out.println("Perdio J2");
            }
        }  
    }
    public static int Minima(int a){
        return a;
    }
    public static int DineroJ1(int i){
        return i;
    }
    public static int DineroJ2(int i){
        return i;
    }
}
